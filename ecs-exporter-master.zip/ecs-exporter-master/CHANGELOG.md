## 1.1.1 / 2017-01-25

* [FIX] Add context to collector so background running goroutines know when the collect iteration finished
* [FEATURE] Add ability using cmd flags to disable container instance metrics gathering

## 1.1.0 / 2016-12-15

* [FEATURE] Add `ecs_container_instances` metrics
* [FEATURE] Add `ecs_container_instance_agent_connected` metrics
* [FEATURE] Add `ecs_container_instance_active` metrics
* [FEATURE] Add `ecs_container_instance_pending_tasks` metrics

## 1.0.1 / 2016-12-11

* [FIX] Rename `ecs_cluster_total` to `ecs_clusters` metrics
* [FIX] Rename `ecs_service_total` to `ecs_services` metrics

## 1.0.0 / 2016-12-11

* [FEATURE] Add `ecs_up` metrics
* [FEATURE] Add `ecs_cluster_total` metrics
* [FEATURE] Add `ecs_service_total` metrics
* [FEATURE] Add `ecs_service_desired_tasks` metrics
* [FEATURE] Add `ecs_service_pending_tasks` metrics
* [FEATURE] Add `ecs_service_running_tasks` metrics
* [FEATURE] Add ability to filter cluster by regular expression
* [FEATURE] Add Exporter logic
